<?php echo "<?php\n"; ?>

namespace <?php echo $namespace; ?>;

use Zenstruck\Foundry\Story;

final class <?php echo $class_name; ?> extends Story
{
    public function build(): void
    {
        // TODO build your story here (https://symfony.com/bundles/ZenstruckFoundryBundle/current/index.html#stories)
    }
}
