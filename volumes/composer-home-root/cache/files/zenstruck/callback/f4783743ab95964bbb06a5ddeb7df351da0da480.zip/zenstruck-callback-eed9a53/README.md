# zenstruck/callback

[![CI Status](https://github.com/zenstruck/callback/workflows/CI/badge.svg)](https://github.com/zenstruck/callback/actions?query=workflow%3ACI)
[![Code Coverage](https://codecov.io/gh/zenstruck/callback/branch/1.x/graph/badge.svg?token=R7OHYYGPKM)](https://codecov.io/gh/zenstruck/callback)
[![Latest Version](https://img.shields.io/packagist/v/zenstruck/callback.svg)](https://packagist.org/packages/zenstruck/callback)

Callable wrapper to validate and inject arguments.

TODO...
